"""
App package for pyBuscaPendencias
Sistema de Consultas SQL - amm_consulta_pendencias
"""

__version__ = "2.0.0"
__author__ = "AMMARHES"